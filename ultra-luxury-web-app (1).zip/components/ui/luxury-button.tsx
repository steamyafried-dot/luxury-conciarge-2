"use client"

import type React from "react"
import { cn } from "@/lib/utils"
import Link from "next/link"
import { forwardRef } from "react"

interface LuxuryButtonProps {
  children: React.ReactNode
  href?: string
  variant?: "primary" | "secondary" | "outline" | "ghost"
  size?: "sm" | "md" | "lg"
  className?: string
  onClick?: () => void
}

export const LuxuryButton = forwardRef<HTMLButtonElement | HTMLAnchorElement, LuxuryButtonProps>(
  ({ children, href, variant = "primary", size = "md", className, onClick }, ref) => {
    const baseStyles = cn(
      "inline-flex items-center justify-center font-mono tracking-[0.25em] uppercase transition-all duration-700 relative overflow-hidden group",
      {
        "text-[9px] px-8 py-4": size === "sm",
        "text-[10px] px-10 py-5": size === "md",
        "text-[11px] px-12 py-6": size === "lg",
      },
      {
        "bg-heritage-green text-ivory hover:bg-heritage-green-light": variant === "primary",
        "bg-ivory text-noir hover:bg-ivory-muted": variant === "secondary",
        "bg-transparent border border-ivory/20 text-ivory/80 hover:border-gold-muted hover:text-ivory":
          variant === "outline",
        "bg-transparent text-ivory/60 hover:text-gold": variant === "ghost",
      },
      className,
    )

    if (href) {
      return (
        <Link href={href} className={baseStyles} ref={ref as React.Ref<HTMLAnchorElement>}>
          <span className="relative z-10">{children}</span>
        </Link>
      )
    }

    return (
      <button onClick={onClick} className={baseStyles} ref={ref as React.Ref<HTMLButtonElement>}>
        <span className="relative z-10">{children}</span>
      </button>
    )
  },
)

LuxuryButton.displayName = "LuxuryButton"
