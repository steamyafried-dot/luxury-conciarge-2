"use client"

import { useRef } from "react"
import Image from "next/image"
import { LuxuryButton } from "@/components/ui/luxury-button"
import { useInView } from "@/hooks/use-in-view"

const services = [
  {
    title: "Private Aviation Coordination",
    description:
      "Access to the world's finest aircraft, available on demand. From intercontinental voyages to regional transfers, each flight is orchestrated to your precise requirements.",
    image: "/private-jet-charter-business-jet-flying-clouds-sun.jpg",
    features: ["Global Fleet Access", "24/7 Operations", "Dedicated Flight Crew", "Bespoke Catering"],
  },
  {
    title: "Helicopter Transfers",
    description:
      "Swift, elegant transfers that transcend conventional routes. Arrive directly at city centers, private estates, or yacht moorings with effortless precision.",
    image: "/helicopter-transfer-landing-rooftop-helipad-city-sk.jpg",
    features: ["Point-to-Point Service", "Airport Connections", "Event Arrivals", "Scenic Routes"],
  },
  {
    title: "Yacht Charters",
    description:
      "The freedom of private seas, with every comfort attended to. From Mediterranean sojourns to Caribbean adventures, our vessels await your command.",
    image: "/yacht-charter-luxury-superyacht-sea-sunset-mediterr.jpg",
    features: ["Crewed Vessels", "Full Provisioning", "Itinerary Planning", "Tender Services"],
  },
  {
    title: "Ultra-Luxury Villas",
    description:
      "Exceptional private residences in the world's most coveted destinations. Each property is vetted for privacy, service, and the standards our members expect.",
    image: "/luxury-villa-pool-ocean-view-mediterranean-sunset-p.jpg",
    features: ["Global Portfolio", "Full Staffing", "Pre-Arrival Service", "Concierge Integration"],
  },
  {
    title: "Five-Star Hotels & Resorts",
    description:
      "Preferred access and elevated experiences at the world's most distinguished properties. Guaranteed upgrades, late departures, and personalized welcome.",
    image: "/five-star-hotel-lobby-luxury-marble-chandelier-eleg.jpg",
    features: ["Partner Properties", "VIP Recognition", "Suite Upgrades", "Exclusive Amenities"],
  },
  {
    title: "Michelin Dining & Private Chefs",
    description:
      "Access to the world's most celebrated tables and private culinary experiences. From impossible reservations to personal chef services in any location.",
    image: "/private-chef-dining-experience-fine-dining-table-ca.jpg",
    features: ["Restaurant Access", "Private Chefs", "Wine Expertise", "Event Catering"],
  },
  {
    title: "Global Events Access",
    description:
      "Privileged entry to the world's most exclusive gatherings. Formula 1 paddock, Fashion Week front rows, Art Basel private previews, and beyond.",
    image: "/formula-one-paddock-vip-access-luxury-hospitality-r.jpg",
    features: ["F1 & Motorsport", "Fashion & Art", "Film Festivals", "Sporting Finals"],
  },
  {
    title: "Security & Close Protection",
    description:
      "Discreet, professional security services delivered by former special forces and intelligence personnel. Your safety, assured without intrusion.",
    image: "/security-close-protection-professional-bodyguard-su.jpg",
    features: ["Executive Protection", "Secure Transport", "Risk Assessment", "Travel Advance"],
  },
  {
    title: "Medical Evacuation",
    description:
      "Comprehensive medical evacuation and repatriation services available globally. Air ambulance coordination with the highest standards of medical care.",
    image: "/medical-evacuation-air-ambulance-helicopter-emergen.jpg",
    features: ["Air Ambulance", "Medical Escort", "Hospital Coordination", "Global Coverage"],
  },
  {
    title: "Lifestyle & Legacy Management",
    description:
      "Holistic management of your personal and family affairs. From property portfolios to succession planning, we attend to the details that matter most.",
    image: "/luxury-office-wealth-management-elegant-interior-de.jpg",
    features: ["Estate Management", "Family Office", "Succession Planning", "Art Advisory"],
  },
]

export function ConciergeServices() {
  return (
    <section className="bg-noir py-28 md:py-40">
      <div className="mx-auto max-w-[1800px] px-8 md:px-16 lg:px-24">
        {/* Section Header */}
        <div className="mb-28 md:mb-36 max-w-2xl">
          <span className="block text-[8px] tracking-[0.6em] uppercase text-gold-muted/50 font-mono mb-6">
            Our Services
          </span>
          <h2 className="text-2xl md:text-3xl font-serif font-light text-ivory/80 tracking-wide leading-[1.4]">
            A complete ecosystem of services, designed for those who expect nothing less than exceptional.
          </h2>
        </div>

        {/* Services Grid */}
        <div className="space-y-40 md:space-y-52">
          {services.map((service, index) => (
            <ServiceItem key={service.title} service={service} index={index} isReversed={index % 2 !== 0} />
          ))}
        </div>
      </div>
    </section>
  )
}

interface ServiceItemProps {
  service: (typeof services)[0]
  index: number
  isReversed: boolean
}

function ServiceItem({ service, index, isReversed }: ServiceItemProps) {
  const ref = useRef<HTMLDivElement>(null)
  const isInView = useInView(ref, { threshold: 0.15 })

  return (
    <div ref={ref} className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-28 items-center">
      {/* Image */}
      <div
        className={`relative aspect-[4/3] overflow-hidden transition-all duration-[2000ms] ease-out ${isReversed ? "lg:order-2" : ""} ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-16"}`}
        style={{ transitionDelay: isReversed ? "300ms" : "0ms" }}
      >
        <Image
          src={service.image || "/placeholder.svg"}
          alt={service.title}
          fill
          className="object-cover transition-transform duration-[3000ms] hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-noir/60 via-noir/20 to-transparent" />
        <div className="absolute bottom-0 left-0 w-20 h-0.5 bg-heritage-green/40" />
      </div>

      {/* Content */}
      <div
        className={`transition-all duration-[2000ms] ease-out ${isReversed ? "lg:order-1" : ""} ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-16"}`}
        style={{ transitionDelay: isReversed ? "0ms" : "300ms" }}
      >
        <span className="block text-[9px] tracking-[0.5em] uppercase text-gold-muted/50 font-mono mb-5">
          {String(index + 1).padStart(2, "0")}
        </span>
        <h3 className="text-2xl md:text-3xl lg:text-4xl font-serif font-light text-ivory tracking-wide leading-[1.2]">
          {service.title}
        </h3>
        <p className="mt-8 text-[11px] md:text-xs text-ivory/40 font-mono leading-[2] tracking-wide">
          {service.description}
        </p>

        {/* Features */}
        <div className="mt-10 grid grid-cols-2 gap-x-10 gap-y-4">
          {service.features.map((feature) => (
            <div key={feature} className="flex items-center gap-4">
              <div className="w-0.5 h-4 bg-heritage-green/40" />
              <span className="text-[10px] text-ivory/50 font-mono tracking-wider">{feature}</span>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-12">
          <LuxuryButton href="/enquiry" variant="outline" size="sm">
            Private Enquiry
          </LuxuryButton>
        </div>
      </div>
    </div>
  )
}
