"use client"

import { useEffect, useState } from "react"
import Image from "next/image"

export function ConciergeHero() {
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 150)
    return () => clearTimeout(timer)
  }, [])

  return (
    <section className="relative h-[75vh] min-h-[650px] w-full overflow-hidden bg-noir">
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image
          src="/luxury-concierge-service-hotel-lobby-marble-golden.jpg"
          alt="Private concierge"
          fill
          className="object-cover opacity-40"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-b from-noir/70 via-noir/50 to-noir" />
        <div className="absolute inset-0 bg-gradient-to-r from-noir/50 via-transparent to-noir/50" />
      </div>

      {/* Content */}
      <div className="relative z-10 flex h-full flex-col items-center justify-center px-8 text-center pt-28">
        <div
          className={`transition-all duration-[3000ms] ease-out ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-20"}`}
        >
          <span className="block text-[8px] md:text-[9px] tracking-[0.7em] uppercase text-gold-muted/70 font-mono mb-10">
            Private Concierge
          </span>
          <h1 className="text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-serif font-light text-ivory tracking-[0.02em] leading-[1.1] max-w-4xl text-balance">
            Every Detail, <br />
            <span className="text-ivory/70">Attended To</span>
          </h1>
          <p
            className={`mt-12 text-[10px] md:text-[11px] text-ivory/35 font-mono tracking-[0.25em] max-w-lg mx-auto leading-[2] transition-all duration-[3000ms] delay-700 ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
          >
            Comprehensive lifestyle management, delivered with discretion and precision.
          </p>
        </div>
      </div>
    </section>
  )
}
