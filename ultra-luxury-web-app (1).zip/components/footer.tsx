import Link from "next/link"

export function Footer() {
  return (
    <footer className="bg-noir border-t border-heritage-green/5">
      <div className="mx-auto max-w-[1800px] px-8 md:px-16 lg:px-24 py-24 md:py-32">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-20 md:gap-12">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex flex-col items-start tracking-[0.4em] uppercase mb-10">
              <span className="text-[7px] text-gold-muted/50 font-mono tracking-[0.6em]">La Maison</span>
              <span className="text-sm text-ivory font-serif font-light tracking-[0.35em] -mt-0.5">Private House</span>
            </div>
            <p className="text-[9px] text-ivory/25 font-mono leading-[2.2] tracking-wider max-w-[200px]">
              An invitation-only sanctuary for those who value discretion, excellence, and timeless service.
            </p>
            <div className="mt-10 pt-8 border-t border-ivory/5">
              <span className="text-[8px] text-gold-muted/40 font-mono tracking-[0.4em]">Est. MMXXIV</span>
            </div>
          </div>

          {/* Navigation - Updated to Concierge, added About */}
          <div>
            <h4 className="text-[8px] tracking-[0.5em] uppercase text-gold-muted/50 font-mono mb-10">Navigation</h4>
            <ul className="space-y-5">
              {["Fleet", "Concierge", "Membership", "Experiences", "About"].map((item) => (
                <li key={item}>
                  <Link
                    href={`/${item.toLowerCase()}`}
                    className="text-[10px] text-ivory/30 hover:text-ivory/70 font-mono tracking-wider transition-colors duration-700"
                  >
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-[8px] tracking-[0.5em] uppercase text-gold-muted/50 font-mono mb-10">Concierge</h4>
            <ul className="space-y-5">
              {[
                "Private Aviation",
                "Helicopter Transfers",
                "Chauffeur Services",
                "Yacht Charter",
                "Security & Protection",
              ].map((item) => (
                <li key={item}>
                  <span className="text-[10px] text-ivory/30 font-mono tracking-wider">{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact - More elegant presentation */}
          <div>
            <h4 className="text-[8px] tracking-[0.5em] uppercase text-gold-muted/50 font-mono mb-10">Private Access</h4>
            <p className="text-[10px] text-ivory/25 font-mono tracking-wider leading-[2] mb-8 max-w-[180px]">
              Membership is by invitation or application only.
            </p>
            <Link
              href="/enquiry"
              className="inline-block text-[10px] text-heritage-green hover:text-heritage-green-light font-mono tracking-[0.3em] uppercase transition-colors duration-700"
            >
              Begin Enquiry
            </Link>
          </div>
        </div>

        {/* Bottom Bar - Refined with heritage green accent */}
        <div className="mt-24 pt-12 border-t border-ivory/5 flex flex-col md:flex-row justify-between items-center gap-8">
          <p className="text-[8px] text-ivory/15 font-mono tracking-wider">
            © {new Date().getFullYear()} The Private House. All rights reserved.
          </p>
          <div className="flex gap-12">
            <Link
              href="/legal/terms"
              className="text-[8px] text-ivory/15 hover:text-ivory/40 font-mono tracking-wider transition-colors duration-700"
            >
              Terms of Service
            </Link>
            <Link
              href="/legal/privacy"
              className="text-[8px] text-ivory/15 hover:text-ivory/40 font-mono tracking-wider transition-colors duration-700"
            >
              Privacy Policy
            </Link>
            <Link
              href="/legal/disclaimer"
              className="text-[8px] text-ivory/15 hover:text-ivory/40 font-mono tracking-wider transition-colors duration-700"
            >
              Disclaimer
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
