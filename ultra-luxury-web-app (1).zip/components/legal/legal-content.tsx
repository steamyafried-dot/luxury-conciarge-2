"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

interface LegalSection {
  title: string
  content: string
}

interface LegalContentProps {
  content: {
    title: string
    lastUpdated: string
    sections: LegalSection[]
  }
}

export function LegalContent({ content }: LegalContentProps) {
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    setIsLoaded(true)
  }, [])

  return (
    <section className="pt-32 pb-24 md:pt-40 md:pb-32">
      <div className="mx-auto max-w-[800px] px-8 md:px-16">
        {/* Back Link */}
        <Link
          href="/"
          className={`inline-flex items-center gap-2 text-[11px] text-ivory/50 hover:text-ivory font-mono tracking-wide transition-all duration-500 mb-12 ${isLoaded ? "opacity-100" : "opacity-0"}`}
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </Link>

        {/* Header */}
        <div
          className={`mb-16 transition-all duration-[1500ms] ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
        >
          <h1 className="text-3xl md:text-4xl font-serif font-light text-ivory tracking-wide">{content.title}</h1>
          <p className="mt-4 text-[11px] text-ivory/40 font-mono tracking-wide">Last updated: {content.lastUpdated}</p>
        </div>

        {/* Content */}
        <div className="space-y-12">
          {content.sections.map((section, index) => (
            <div
              key={section.title}
              className={`transition-all duration-[1500ms] ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
              style={{ transitionDelay: `${(index + 1) * 100}ms` }}
            >
              <h2 className="text-lg font-serif font-light text-ivory tracking-wide mb-4">{section.title}</h2>
              <p className="text-sm text-ivory/50 font-mono leading-relaxed tracking-wide">{section.content}</p>
            </div>
          ))}
        </div>

        {/* Footer Links */}
        <div
          className={`mt-20 pt-8 border-t border-border/20 transition-all duration-[1500ms] delay-1000 ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
        >
          <div className="flex flex-wrap gap-8">
            <Link
              href="/legal/terms"
              className="text-[11px] text-ivory/40 hover:text-ivory font-mono tracking-wide transition-colors duration-300"
            >
              Terms of Service
            </Link>
            <Link
              href="/legal/privacy"
              className="text-[11px] text-ivory/40 hover:text-ivory font-mono tracking-wide transition-colors duration-300"
            >
              Privacy Policy
            </Link>
            <Link
              href="/legal/disclaimer"
              className="text-[11px] text-ivory/40 hover:text-ivory font-mono tracking-wide transition-colors duration-300"
            >
              Disclaimer
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
