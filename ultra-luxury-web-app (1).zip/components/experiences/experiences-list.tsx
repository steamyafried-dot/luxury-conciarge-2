"use client"

import { useRef } from "react"
import Image from "next/image"
import { LuxuryButton } from "@/components/ui/luxury-button"
import { useInView } from "@/hooks/use-in-view"

const experiences = [
  {
    category: "Culinary",
    title: "Private Dining Journeys",
    description:
      "Intimate evenings with Michelin-starred chefs in extraordinary settings. From private wine cellars to coastal villas, each meal tells a story.",
    image: "/experience-private-dining-michelin-chef-luxury-tabl.jpg",
    highlights: ["Chef's Table Experiences", "Wine Cellar Dinners", "Truffle Season Journeys", "Coastal Feasts"],
  },
  {
    category: "Cultural",
    title: "Art & Heritage Access",
    description:
      "Private viewings of world-renowned collections, after-hours museum access, and introductions to contemporary masters.",
    image: "/experience-art-gallery-private-viewing-sculpture-mu.jpg",
    highlights: ["Private Gallery Tours", "Artist Studio Visits", "Auction House Access", "Collection Curation"],
  },
  {
    category: "Adventure",
    title: "Expedition Journeys",
    description:
      "From polar expeditions to African safaris, adventures designed for those who seek the extraordinary without compromising comfort.",
    image: "/experience-safari-luxury-lodge-african-sunset-wildl.jpg",
    highlights: ["Arctic Expeditions", "African Safaris", "Mountain Retreats", "Ocean Voyages"],
  },
  {
    category: "Wellness",
    title: "Retreat & Renewal",
    description:
      "Transformative wellness experiences at the world's most exclusive sanctuaries. Body, mind, and spirit—restored.",
    image: "/experience-wellness-spa-luxury-massage-mountain-vie.jpg",
    highlights: ["Private Spa Retreats", "Wellness Immersions", "Yoga Journeys", "Detox Programs"],
  },
  {
    category: "Sporting",
    title: "Elite Sporting Events",
    description:
      "Privileged access to the world's most prestigious sporting occasions. From Monaco to Wimbledon, experience sport at its finest.",
    image: "/experience-sporting-event-vip-box-champagne-racing-.jpg",
    highlights: ["Formula 1 Paddock", "Grand Slam Tennis", "Polo Matches", "Golf Majors"],
  },
  {
    category: "Celebration",
    title: "Milestone Occasions",
    description:
      "Landmark celebrations designed to exceed every expectation. Venues, entertainment, and details orchestrated to perfection.",
    image: "/experience-celebration-luxury-party-fireworks-villa.jpg",
    highlights: ["Anniversary Celebrations", "Private Concerts", "Island Buyouts", "Family Reunions"],
  },
]

export function ExperiencesList() {
  return (
    <section className="bg-charcoal py-24 md:py-32">
      <div className="mx-auto max-w-[1800px] px-8 md:px-16 lg:px-24">
        <div className="space-y-24 md:space-y-32">
          {experiences.map((experience, index) => (
            <ExperienceItem key={experience.title} experience={experience} index={index} isReversed={index % 2 !== 0} />
          ))}
        </div>
      </div>
    </section>
  )
}

interface ExperienceItemProps {
  experience: (typeof experiences)[0]
  index: number
  isReversed: boolean
}

function ExperienceItem({ experience, index, isReversed }: ExperienceItemProps) {
  const ref = useRef<HTMLDivElement>(null)
  const isInView = useInView(ref, { threshold: 0.2 })

  return (
    <div ref={ref} className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24 items-center">
      {/* Image */}
      <div
        className={`relative aspect-[4/3] lg:aspect-[3/4] overflow-hidden transition-all duration-[1500ms] ${isReversed ? "lg:order-2" : ""} ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
        style={{ transitionDelay: isReversed ? "200ms" : "0ms" }}
      >
        <Image
          src={experience.image || "/placeholder.svg"}
          alt={experience.title}
          fill
          className="object-cover transition-transform duration-[2000ms] hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-charcoal/50 to-transparent" />

        {/* Category Badge */}
        <div className="absolute top-6 left-6">
          <span className="px-3 py-1.5 bg-charcoal/80 backdrop-blur-sm text-[9px] tracking-[0.3em] uppercase text-gold font-mono">
            {experience.category}
          </span>
        </div>
      </div>

      {/* Content */}
      <div
        className={`transition-all duration-[1500ms] ${isReversed ? "lg:order-1" : ""} ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
        style={{ transitionDelay: isReversed ? "0ms" : "200ms" }}
      >
        <h2 className="text-2xl md:text-3xl lg:text-4xl font-serif font-light text-ivory tracking-wide leading-tight">
          {experience.title}
        </h2>
        <p className="mt-6 text-sm md:text-base text-ivory/50 font-mono leading-relaxed tracking-wide">
          {experience.description}
        </p>

        {/* Highlights */}
        <div className="mt-8 grid grid-cols-2 gap-x-8 gap-y-3">
          {experience.highlights.map((highlight) => (
            <div key={highlight} className="flex items-center gap-3">
              <div className="w-1 h-4 bg-gold/30" />
              <span className="text-[11px] text-ivory/60 font-mono tracking-wide">{highlight}</span>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-10">
          <LuxuryButton href="/enquiry" variant="outline" size="sm">
            Begin Planning
          </LuxuryButton>
        </div>
      </div>
    </div>
  )
}
