"use client"

import { useEffect, useState } from "react"
import Image from "next/image"

export function AboutHero() {
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 150)
    return () => clearTimeout(timer)
  }, [])

  return (
    <section className="relative h-[80vh] min-h-[700px] w-full overflow-hidden bg-noir">
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image
          src="/luxury-private-library-leather-books-fireplace-dar.jpg"
          alt="The Private House"
          fill
          className="object-cover opacity-35"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-b from-noir/60 via-noir/40 to-noir" />
        <div className="absolute inset-0 bg-gradient-to-r from-noir/60 via-transparent to-noir/60" />
      </div>

      {/* Content */}
      <div className="relative z-10 flex h-full flex-col items-center justify-center px-8 text-center pt-28">
        <div
          className={`transition-all duration-[3500ms] ease-out ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-24"}`}
        >
          <span className="block text-[7px] md:text-[8px] tracking-[0.8em] uppercase text-gold-muted/60 font-mono mb-12">
            La Maison · Est. MMXXIV
          </span>
          <h1 className="text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-serif font-light text-ivory tracking-[0.03em] leading-[1.08] max-w-4xl text-balance">
            A House Built
            <br />
            <span className="text-ivory/60">on Trust</span>
          </h1>
          <p
            className={`mt-14 text-[10px] md:text-[11px] text-ivory/30 font-mono tracking-[0.3em] uppercase max-w-md mx-auto transition-all duration-[3500ms] delay-700 ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
          >
            Privacy · Excellence · Legacy
          </p>
        </div>
      </div>
    </section>
  )
}
