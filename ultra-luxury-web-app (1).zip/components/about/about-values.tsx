"use client"

import { useRef } from "react"
import { useInView } from "@/hooks/use-in-view"
import { LuxuryButton } from "@/components/ui/luxury-button"

const values = [
  {
    title: "Absolute Privacy",
    description:
      "Your affairs remain yours alone. We maintain the strictest confidentiality in all communications and never discuss our members or their arrangements.",
  },
  {
    title: "Generational Relationships",
    description:
      "We build relationships that transcend transactions. Many of our members are now second-generation, a testament to the trust we have earned over decades.",
  },
  {
    title: "Uncompromising Standards",
    description:
      "We accept nothing less than excellence in every detail. From our partners to our personnel, every element meets the standards our members expect.",
  },
  {
    title: "Global Reach, Personal Touch",
    description:
      "Our network spans continents, yet every interaction feels personal. One dedicated point of contact, available whenever needed, wherever you are.",
  },
  {
    title: "Legacy Stewardship",
    description:
      "We understand that our members' concerns extend beyond their own lifetimes. We assist in preserving and transferring wealth, values, and traditions.",
  },
  {
    title: "Invitation Only",
    description:
      "Membership to The Private House is by invitation or careful application. We serve a finite number of families, ensuring each receives our undivided attention.",
  },
]

export function AboutValues() {
  const ref = useRef<HTMLDivElement>(null)
  const isInView = useInView(ref, { threshold: 0.1 })

  return (
    <section ref={ref} className="bg-noir-light py-32 md:py-44">
      <div className="mx-auto max-w-[1800px] px-8 md:px-16 lg:px-24">
        {/* Header */}
        <div
          className={`mb-24 md:mb-32 text-center transition-all duration-[2500ms] ease-out ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-16"}`}
        >
          <span className="block text-[8px] tracking-[0.6em] uppercase text-gold-muted/50 font-mono mb-8">
            Our Values
          </span>
          <h2 className="text-3xl md:text-4xl font-serif font-light text-ivory tracking-wide leading-[1.2] max-w-2xl mx-auto">
            The Principles That
            <br />
            <span className="text-ivory/60">Guide Every Action</span>
          </h2>
        </div>

        {/* Values Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-12 gap-y-20">
          {values.map((value, index) => (
            <div
              key={value.title}
              className={`transition-all duration-[2000ms] ease-out ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-16"}`}
              style={{ transitionDelay: `${index * 150}ms` }}
            >
              <div className="flex items-center gap-5 mb-6">
                <div className="w-8 h-px bg-heritage-green/50" />
                <span className="text-[9px] text-gold-muted/50 font-mono tracking-[0.4em]">
                  {String(index + 1).padStart(2, "0")}
                </span>
              </div>
              <h3 className="text-lg md:text-xl font-serif font-light text-ivory tracking-wide mb-5">{value.title}</h3>
              <p className="text-[10px] text-ivory/35 font-mono leading-[2.2] tracking-wide">{value.description}</p>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div
          className={`mt-28 md:mt-36 text-center transition-all duration-[2500ms] delay-700 ease-out ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
        >
          <p className="text-[11px] text-ivory/30 font-mono tracking-wider mb-10 max-w-md mx-auto">
            If our values align with yours, we welcome your enquiry.
          </p>
          <LuxuryButton href="/enquiry" variant="primary" size="md">
            Apply for Private Access
          </LuxuryButton>
        </div>
      </div>
    </section>
  )
}
