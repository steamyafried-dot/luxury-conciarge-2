"use client"

import { useRef } from "react"
import Image from "next/image"
import { useInView } from "@/hooks/use-in-view"

export function AboutPhilosophy() {
  const ref = useRef<HTMLDivElement>(null)
  const isInView = useInView(ref, { threshold: 0.2 })

  return (
    <section ref={ref} className="bg-noir py-32 md:py-44">
      <div className="mx-auto max-w-[1800px] px-8 md:px-16 lg:px-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 lg:gap-32 items-center">
          {/* Image */}
          <div
            className={`relative aspect-[3/4] overflow-hidden transition-all duration-[2500ms] ease-out ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-20"}`}
          >
            <Image
              src="/luxury-heritage-mansion-entrance-columns-elegant-a.jpg"
              alt="Heritage and tradition"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-noir/50 to-transparent" />
            <div className="absolute bottom-0 left-0 w-24 h-0.5 bg-heritage-green/40" />
          </div>

          {/* Content */}
          <div
            className={`transition-all duration-[2500ms] delay-300 ease-out ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-20"}`}
          >
            <span className="block text-[8px] tracking-[0.6em] uppercase text-gold-muted/50 font-mono mb-8">
              Our Philosophy
            </span>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-serif font-light text-ivory tracking-wide leading-[1.15]">
              Discretion is Not
              <br />
              <span className="text-ivory/60">a Feature. It is</span>
              <br />
              <span className="text-ivory/60">Our Foundation.</span>
            </h2>

            <div className="mt-14 space-y-8">
              <p className="text-[11px] md:text-xs text-ivory/40 font-mono leading-[2.2] tracking-wide">
                The Private House was founded on a singular principle: that true luxury is measured not in ostentation,
                but in the quiet confidence of absolute privacy and impeccable service.
              </p>
              <p className="text-[11px] md:text-xs text-ivory/35 font-mono leading-[2.2] tracking-wide">
                We serve a distinguished clientele who have achieved remarkable success and now seek a partner who
                understands that the most valuable currency is trust. Our relationships span generations, built on an
                unwavering commitment to discretion and excellence.
              </p>
              <p className="text-[11px] md:text-xs text-ivory/35 font-mono leading-[2.2] tracking-wide">
                Every member of The Private House is attended to with the same care and attention, whether arranging a
                transcontinental journey or securing an impossible reservation. There is no request too complex, no
                detail too small.
              </p>
            </div>

            {/* Heritage accent */}
            <div className="mt-16 pt-10 border-t border-ivory/5">
              <span className="text-[9px] text-gold-muted/40 font-mono tracking-[0.4em]">
                "Excellence is not an act, but a habit."
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
