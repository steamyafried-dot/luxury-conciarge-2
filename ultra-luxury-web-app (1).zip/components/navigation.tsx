"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Menu, X } from "lucide-react"

const navLinks = [
  { href: "/fleet", label: "Fleet" },
  { href: "/concierge", label: "Concierge" },
  { href: "/membership", label: "Membership" },
  { href: "/experiences", label: "Experiences" },
  { href: "/about", label: "About" },
]

export function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const pathname = usePathname()

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <>
      <nav
        className={cn(
          "fixed top-0 left-0 right-0 z-50 transition-all duration-[1500ms] ease-out",
          isScrolled ? "bg-noir/98 backdrop-blur-2xl border-b border-heritage-green/10" : "bg-transparent",
        )}
      >
        <div className="mx-auto max-w-[1800px] px-8 md:px-16 lg:px-24">
          <div className="flex h-28 md:h-32 items-center justify-between">
            <Link href="/" className="group flex flex-col items-start tracking-[0.4em] uppercase">
              <span className="text-[7px] md:text-[8px] text-gold-muted/60 font-mono tracking-[0.6em] opacity-70 group-hover:text-gold-muted transition-colors duration-700">
                La Maison
              </span>
              <span className="text-sm md:text-base text-ivory font-serif font-light tracking-[0.35em] -mt-0.5 group-hover:text-ivory/90 transition-colors duration-700">
                Private House
              </span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-16">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={cn(
                    "text-[9px] tracking-[0.35em] uppercase font-mono transition-all duration-700 relative",
                    pathname === link.href || pathname.startsWith(link.href + "/")
                      ? "text-gold"
                      : "text-ivory/40 hover:text-ivory/80",
                  )}
                >
                  {link.label}
                  {(pathname === link.href || pathname.startsWith(link.href + "/")) && (
                    <span className="absolute -bottom-1 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold-muted/50 to-transparent" />
                  )}
                </Link>
              ))}
              <Link
                href="/enquiry"
                className="text-[9px] tracking-[0.35em] uppercase font-mono text-heritage-green hover:text-heritage-green-light transition-all duration-700 border border-heritage-green/30 hover:border-heritage-green/60 px-6 py-3"
              >
                Private Enquiry
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden text-ivory/60 p-2 hover:text-ivory transition-colors duration-700"
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? <X size={20} strokeWidth={0.75} /> : <Menu size={20} strokeWidth={0.75} />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div
        className={cn(
          "fixed inset-0 z-40 bg-noir/[0.995] backdrop-blur-3xl transition-all duration-[1200ms] md:hidden",
          isMobileMenuOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none",
        )}
      >
        <div className="flex flex-col items-center justify-center h-full gap-12">
          {navLinks.map((link, index) => (
            <Link
              key={link.href}
              href={link.href}
              onClick={() => setIsMobileMenuOpen(false)}
              className={cn(
                "text-lg tracking-[0.5em] uppercase font-serif font-light transition-all duration-700",
                pathname === link.href ? "text-gold" : "text-ivory/50 hover:text-ivory",
                isMobileMenuOpen && "animate-fade-in-up",
              )}
              style={{ animationDelay: `${(index + 1) * 200}ms` }}
            >
              {link.label}
            </Link>
          ))}
          <Link
            href="/enquiry"
            onClick={() => setIsMobileMenuOpen(false)}
            className={cn(
              "mt-4 text-sm tracking-[0.4em] uppercase font-mono text-heritage-green border border-heritage-green/40 px-8 py-4 transition-all duration-700 hover:bg-heritage-green/10",
              isMobileMenuOpen && "animate-fade-in-up",
            )}
            style={{ animationDelay: `${(navLinks.length + 1) * 200}ms` }}
          >
            Private Enquiry
          </Link>
        </div>
      </div>
    </>
  )
}
