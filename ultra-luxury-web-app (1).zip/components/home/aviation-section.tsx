"use client"

import { useRef } from "react"
import Image from "next/image"
import { LuxuryButton } from "@/components/ui/luxury-button"
import { useInView } from "@/hooks/use-in-view"

export function AviationSection() {
  const ref = useRef<HTMLElement>(null)
  const isInView = useInView(ref, { threshold: 0.2 })

  return (
    <section ref={ref} className="relative min-h-screen bg-charcoal py-32 md:py-40">
      <div className="mx-auto max-w-[1800px] px-8 md:px-16 lg:px-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-center">
          {/* Content */}
          <div
            className={`transition-all duration-[1500ms] ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
          >
            <span className="block text-[10px] md:text-[11px] tracking-[0.4em] uppercase text-gold-muted font-mono mb-6">
              Private Aviation
            </span>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-serif font-light text-ivory tracking-wide leading-tight text-balance">
              Above the World, Beyond Expectation
            </h2>
            <p className="mt-8 text-sm md:text-base text-ivory/50 font-mono leading-relaxed tracking-wide max-w-lg">
              From intercontinental voyages to regional transfers, our fleet of elite aircraft awaits. Each journey
              crafted with absolute discretion.
            </p>
            <div className="mt-12">
              <LuxuryButton href="/fleet" variant="outline">
                Explore Fleet
              </LuxuryButton>
            </div>
          </div>

          {/* Image */}
          <div
            className={`relative aspect-[4/5] lg:aspect-[3/4] overflow-hidden transition-all duration-[1500ms] delay-300 ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
          >
            <Image
              src="/gulfstream-private-jet-interior-luxury-leather-sea.jpg"
              alt="Private jet interior"
              fill
              className="object-cover transition-transform duration-[2000ms] hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-charcoal/40 to-transparent" />
          </div>
        </div>
      </div>
    </section>
  )
}
