"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { ChevronDown } from "lucide-react"

export function HeroSection() {
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 200)
    return () => clearTimeout(timer)
  }, [])

  return (
    <section className="relative h-screen w-full overflow-hidden bg-noir">
      {/* Video Background */}
      <div className="absolute inset-0">
        <video
          autoPlay
          muted
          loop
          playsInline
          className="h-full w-full object-cover scale-105 opacity-50"
          poster="/luxury-private-jet-hangar-at-dusk-cinematic.jpg"
        >
          <source
            src="https://videos.pexels.com/video-files/3571264/3571264-uhd_2560_1440_30fps.mp4"
            type="video/mp4"
          />
        </video>
        <div className="absolute inset-0 bg-gradient-to-b from-noir/90 via-noir/60 to-noir" />
        <div className="absolute inset-0 bg-gradient-to-r from-noir/50 via-transparent to-noir/50" />
      </div>

      {/* Hero Content */}
      <div className="relative z-10 flex h-full flex-col items-center justify-center px-8 text-center">
        <div
          className={`transition-all duration-[4000ms] ease-out ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-20"}`}
        >
          <span className="block text-[7px] md:text-[8px] tracking-[0.8em] uppercase text-gold-muted/60 font-mono mb-10">
            Est. MMXXIV · Paris
          </span>

          <h1 className="text-4xl md:text-5xl lg:text-7xl xl:text-8xl font-serif font-light text-ivory tracking-[0.03em] leading-[1.05] max-w-5xl text-balance">
            A Private World
            <br />
            <span className="text-ivory/60">Reserved for the Few</span>
          </h1>

          <p
            className={`mt-14 text-[9px] md:text-[10px] text-ivory/30 font-mono tracking-[0.4em] uppercase max-w-md mx-auto transition-all duration-[4000ms] delay-1000 ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
          >
            Aviation · Mobility · Bespoke Luxury
          </p>

          <div
            className={`mt-16 transition-all duration-[4000ms] delay-1500 ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
          >
            <Link
              href="/enquiry"
              className="inline-block text-[9px] tracking-[0.4em] uppercase font-mono text-ivory/40 hover:text-ivory/70 border-b border-ivory/10 hover:border-ivory/30 pb-1 transition-all duration-700"
            >
              Private Enquiry
            </Link>
          </div>
        </div>
      </div>

      <div className="absolute bottom-20 left-1/2 -translate-x-1/2 z-10">
        <div className="flex flex-col items-center gap-5 animate-slow-pulse">
          <span className="text-[7px] tracking-[0.6em] uppercase text-ivory/20 font-mono">Discover</span>
          <ChevronDown className="w-3.5 h-3.5 text-ivory/20" strokeWidth={0.75} />
        </div>
      </div>
    </section>
  )
}
