"use client"

import { useRef } from "react"
import Image from "next/image"
import { LuxuryButton } from "@/components/ui/luxury-button"
import { useInView } from "@/hooks/use-in-view"

export function MobilitySection() {
  const ref = useRef<HTMLElement>(null)
  const isInView = useInView(ref, { threshold: 0.2 })

  return (
    <section ref={ref} className="relative min-h-screen bg-charcoal-light py-32 md:py-40">
      <div className="mx-auto max-w-[1800px] px-8 md:px-16 lg:px-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-center">
          {/* Image - Order reversed on desktop */}
          <div
            className={`relative aspect-[4/5] lg:aspect-[3/4] overflow-hidden order-2 lg:order-1 transition-all duration-[1500ms] delay-300 ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
          >
            <Image
              src="/rolls-royce-phantom-black-luxury-car-chauffeur-nig.jpg"
              alt="Luxury ground transport"
              fill
              className="object-cover transition-transform duration-[2000ms] hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-charcoal-light/40 to-transparent" />
          </div>

          {/* Content */}
          <div
            className={`order-1 lg:order-2 transition-all duration-[1500ms] ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
          >
            <span className="block text-[10px] md:text-[11px] tracking-[0.4em] uppercase text-gold-muted font-mono mb-6">
              Ground Mobility
            </span>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-serif font-light text-ivory tracking-wide leading-tight text-balance">
              Every Arrival, an Occasion
            </h2>
            <p className="mt-8 text-sm md:text-base text-ivory/50 font-mono leading-relaxed tracking-wide max-w-lg">
              Chauffeured excellence across the world&apos;s most distinguished destinations. Rolls-Royce, Bentley,
              Maybach—ready when you are.
            </p>
            <div className="mt-12">
              <LuxuryButton href="/fleet" variant="outline">
                View Collection
              </LuxuryButton>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
