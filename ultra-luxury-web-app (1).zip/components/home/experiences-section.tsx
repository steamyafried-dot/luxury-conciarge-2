"use client"

import { useRef } from "react"
import Image from "next/image"
import { LuxuryButton } from "@/components/ui/luxury-button"
import { useInView } from "@/hooks/use-in-view"

const experiences = [
  {
    title: "Private Dining",
    description: "Michelin-starred chefs, curated menus, extraordinary settings.",
    image: "/private-dining-luxury-table-setting-candlelight-in.jpg",
  },
  {
    title: "Bespoke Retreats",
    description: "Exclusive estates and villas, arranged with absolute privacy.",
    image: "/luxury-villa-pool-sunset-mediterranean-exclusive-e.jpg",
  },
  {
    title: "Cultural Journeys",
    description: "Private access to art, heritage, and rare collections worldwide.",
    image: "/private-museum-tour-art-gallery-exclusive-viewing-.jpg",
  },
]

export function ExperiencesSection() {
  const ref = useRef<HTMLElement>(null)
  const isInView = useInView(ref, { threshold: 0.15 })

  return (
    <section ref={ref} className="relative bg-charcoal py-32 md:py-40">
      <div className="mx-auto max-w-[1800px] px-8 md:px-16 lg:px-24">
        {/* Header */}
        <div
          className={`max-w-2xl mb-20 transition-all duration-[1500ms] ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
        >
          <span className="block text-[10px] md:text-[11px] tracking-[0.4em] uppercase text-gold-muted font-mono mb-6">
            Bespoke Experiences
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-serif font-light text-ivory tracking-wide leading-tight text-balance">
            Moments Crafted, Never Replicated
          </h2>
        </div>

        {/* Experience Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-12">
          {experiences.map((experience, index) => (
            <div
              key={experience.title}
              className={`group transition-all duration-[1500ms] ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
              style={{ transitionDelay: `${(index + 1) * 200}ms` }}
            >
              <div className="relative aspect-[3/4] overflow-hidden mb-6">
                <Image
                  src={experience.image || "/placeholder.svg"}
                  alt={experience.title}
                  fill
                  className="object-cover transition-transform duration-[2000ms] group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-charcoal/60 to-transparent" />
              </div>
              <h3 className="text-xl md:text-2xl font-serif font-light text-ivory tracking-wide mb-3">
                {experience.title}
              </h3>
              <p className="text-xs text-ivory/50 font-mono leading-relaxed tracking-wide">{experience.description}</p>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div
          className={`mt-16 transition-all duration-[1500ms] delay-700 ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
        >
          <LuxuryButton href="/experiences" variant="outline">
            Explore Experiences
          </LuxuryButton>
        </div>
      </div>
    </section>
  )
}
