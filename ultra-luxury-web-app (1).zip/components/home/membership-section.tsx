"use client"

import { useRef } from "react"
import Image from "next/image"
import { LuxuryButton } from "@/components/ui/luxury-button"
import { useInView } from "@/hooks/use-in-view"

export function MembershipSection() {
  const ref = useRef<HTMLElement>(null)
  const isInView = useInView(ref, { threshold: 0.2 })

  return (
    <section ref={ref} className="relative min-h-screen bg-forest py-32 md:py-40 overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image src="/luxury-private-club-interior-dark-wood-elegant-lib.jpg" alt="Private membership" fill className="object-cover opacity-30" />
        <div className="absolute inset-0 bg-gradient-to-r from-forest via-forest/95 to-forest/80" />
      </div>

      {/* Content */}
      <div className="relative z-10 mx-auto max-w-[1800px] px-8 md:px-16 lg:px-24">
        <div className="max-w-2xl">
          <div
            className={`transition-all duration-[1500ms] ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
          >
            <span className="block text-[10px] md:text-[11px] tracking-[0.4em] uppercase text-gold font-mono mb-6">
              Private Membership
            </span>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-serif font-light text-ivory tracking-wide leading-tight text-balance">
              An Invitation to the Exceptional
            </h2>
            <p className="mt-8 text-sm md:text-base text-ivory/60 font-mono leading-relaxed tracking-wide max-w-lg">
              Membership to The Private House is by invitation or referral only. Our members enjoy priority access,
              dedicated concierge services, and privileges reserved for the few.
            </p>
          </div>

          {/* Tiers Preview */}
          <div
            className={`mt-16 flex flex-col sm:flex-row gap-8 transition-all duration-[1500ms] delay-300 ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
          >
            {["House Access", "House Privé", "House Black"].map((tier) => (
              <div key={tier} className="flex items-center gap-3">
                <div className="w-1 h-8 bg-gold/30" />
                <span className="text-xs tracking-[0.2em] uppercase text-ivory/70 font-mono">{tier}</span>
              </div>
            ))}
          </div>

          {/* CTA */}
          <div
            className={`mt-16 transition-all duration-[1500ms] delay-500 ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
          >
            <LuxuryButton href="/membership" variant="secondary">
              Learn More
            </LuxuryButton>
          </div>
        </div>
      </div>
    </section>
  )
}
