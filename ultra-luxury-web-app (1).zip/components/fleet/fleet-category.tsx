"use client"

import { useRef } from "react"
import Image from "next/image"
import Link from "next/link"
import { useInView } from "@/hooks/use-in-view"
import type { FleetCategoryType } from "@/lib/fleet-data"

interface FleetCategoryProps {
  category: FleetCategoryType
  isReversed?: boolean
}

export function FleetCategory({ category, isReversed = false }: FleetCategoryProps) {
  const ref = useRef<HTMLElement>(null)
  const isInView = useInView(ref, { threshold: 0.15 })

  return (
    <section ref={ref} id={category.id} className="relative bg-charcoal py-24 md:py-32 border-t border-border/10">
      <div className="mx-auto max-w-[1800px] px-8 md:px-16 lg:px-24">
        {/* Category Header */}
        <div
          className={`mb-16 transition-all duration-[1500ms] ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
        >
          <span className="block text-[10px] md:text-[11px] tracking-[0.4em] uppercase text-gold-muted font-mono mb-4">
            {category.eyebrow}
          </span>
          <h2 className="text-3xl md:text-4xl font-serif font-light text-ivory tracking-wide">{category.title}</h2>
          <p className="mt-4 text-sm text-ivory/50 font-mono tracking-wide max-w-2xl">{category.description}</p>
        </div>

        {/* Fleet Items Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-12">
          {category.items.map((item, index) => (
            <Link
              href={`/fleet/${category.id}/${item.slug}`}
              key={item.slug}
              className={`group transition-all duration-[1500ms] ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
              style={{ transitionDelay: `${(index + 1) * 150}ms` }}
            >
              {/* Image */}
              <div className="relative aspect-[4/3] overflow-hidden mb-6">
                <Image
                  src={item.image || "/placeholder.svg"}
                  alt={item.name}
                  fill
                  className="object-cover transition-transform duration-[2000ms] group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-charcoal/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
              </div>

              {/* Info */}
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h3 className="text-lg md:text-xl font-serif font-light text-ivory tracking-wide group-hover:text-gold transition-colors duration-500">
                    {item.name}
                  </h3>
                  <p className="mt-1 text-[11px] text-ivory/40 font-mono tracking-wide">{item.subtitle}</p>
                </div>
                <span className="text-[10px] text-gold-muted font-mono tracking-wider opacity-0 group-hover:opacity-100 transition-opacity duration-500 mt-1">
                  View
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
