"use client"

import { useEffect, useState } from "react"

export function FleetHero() {
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    setIsLoaded(true)
  }, [])

  return (
    <section className="relative h-[70vh] min-h-[600px] w-full overflow-hidden bg-charcoal">
      {/* Background Image */}
      <div className="absolute inset-0">
        <video
          autoPlay
          muted
          loop
          playsInline
          className="h-full w-full object-cover opacity-60"
          poster="/private-jet-fleet-hangar-multiple-aircraft-luxury-.jpg"
        >
          <source
            src="https://videos.pexels.com/video-files/5765269/5765269-uhd_2560_1440_24fps.mp4"
            type="video/mp4"
          />
        </video>
        <div className="absolute inset-0 bg-gradient-to-b from-charcoal/60 via-charcoal/40 to-charcoal" />
      </div>

      {/* Content */}
      <div className="relative z-10 flex h-full flex-col items-center justify-center px-8 text-center pt-24">
        <div
          className={`transition-all duration-[2000ms] ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
        >
          <span className="block text-[10px] md:text-xs tracking-[0.5em] uppercase text-gold-muted font-mono mb-6">
            The Collection
          </span>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-light text-ivory tracking-wide leading-[1.1] max-w-3xl text-balance">
            Uncompromising Excellence
          </h1>
          <p
            className={`mt-8 text-sm md:text-base text-ivory/50 font-mono tracking-wider max-w-xl mx-auto transition-all duration-[2000ms] delay-500 ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
          >
            From the skies to the seas, our fleet represents the pinnacle of private mobility.
          </p>
        </div>
      </div>
    </section>
  )
}
