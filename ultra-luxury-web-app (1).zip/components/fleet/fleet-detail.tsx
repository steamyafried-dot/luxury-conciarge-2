"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import { LuxuryButton } from "@/components/ui/luxury-button"
import type { FleetItem } from "@/lib/fleet-data"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

interface FleetDetailProps {
  item: FleetItem
  categoryTitle: string
}

export function FleetDetail({ item, categoryTitle }: FleetDetailProps) {
  const [isLoaded, setIsLoaded] = useState(false)
  const [activeImage, setActiveImage] = useState(0)

  useEffect(() => {
    setIsLoaded(true)
  }, [])

  const images = [item.image, item.interiorImage, item.detailImage].filter(Boolean) as string[]

  return (
    <div className="pt-24 md:pt-32">
      {/* Back Link */}
      <div className="mx-auto max-w-[1800px] px-8 md:px-16 lg:px-24 mb-8">
        <Link
          href="/fleet"
          className="inline-flex items-center gap-2 text-[11px] text-ivory/50 hover:text-ivory font-mono tracking-wide transition-colors duration-300"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Fleet
        </Link>
      </div>

      <div className="mx-auto max-w-[1800px] px-8 md:px-16 lg:px-24 pb-24 md:pb-32">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">
          {/* Images */}
          <div
            className={`transition-all duration-[1500ms] ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
          >
            {/* Main Image */}
            <div className="relative aspect-[4/3] overflow-hidden mb-4">
              <Image
                src={images[activeImage] || "/placeholder.svg"}
                alt={item.name}
                fill
                className="object-cover"
                priority
              />
            </div>

            {/* Thumbnails */}
            {images.length > 1 && (
              <div className="flex gap-4">
                {images.map((img, index) => (
                  <button
                    key={index}
                    onClick={() => setActiveImage(index)}
                    className={`relative aspect-[4/3] w-24 overflow-hidden border-2 transition-all duration-300 ${activeImage === index ? "border-gold" : "border-transparent opacity-60 hover:opacity-100"}`}
                  >
                    <Image
                      src={img || "/placeholder.svg"}
                      alt={`${item.name} view ${index + 1}`}
                      fill
                      className="object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Content */}
          <div
            className={`transition-all duration-[1500ms] delay-200 ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
          >
            <span className="block text-[10px] md:text-[11px] tracking-[0.4em] uppercase text-gold-muted font-mono mb-4">
              {categoryTitle}
            </span>
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-serif font-light text-ivory tracking-wide leading-tight">
              {item.name}
            </h1>
            <p className="mt-2 text-sm text-ivory/40 font-mono tracking-wide">{item.subtitle}</p>

            <p className="mt-8 text-sm md:text-base text-ivory/60 font-mono leading-relaxed tracking-wide">
              {item.description}
            </p>

            {/* Specifications */}
            {item.specs && (
              <div className="mt-12 border-t border-border/20 pt-8">
                <h3 className="text-[10px] tracking-[0.3em] uppercase text-gold-muted font-mono mb-6">
                  Specifications
                </h3>
                <div className="grid grid-cols-2 gap-x-8 gap-y-4">
                  {Object.entries(item.specs).map(([key, value]) => (
                    <div key={key}>
                      <span className="block text-[10px] text-ivory/40 font-mono tracking-wide uppercase mb-1">
                        {key}
                      </span>
                      <span className="text-sm text-ivory font-mono tracking-wide">{value}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* CTA */}
            <div className="mt-12">
              <LuxuryButton href="/enquiry" variant="primary" size="lg">
                Private Enquiry
              </LuxuryButton>
            </div>

            <p className="mt-6 text-[10px] text-ivory/30 font-mono tracking-wide">
              All requests are handled with absolute discretion.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
