"use client"

import { useRef } from "react"
import Image from "next/image"
import { useInView } from "@/hooks/use-in-view"

const benefits = [
  {
    title: "Discretion",
    description:
      "Your privacy is paramount. Every interaction, every arrangement, handled with absolute confidentiality.",
  },
  {
    title: "Access",
    description: "Doors that remain closed to others open for our members. From sold-out events to private viewings.",
  },
  {
    title: "Priority",
    description: "When demand exceeds supply, members come first. Guaranteed availability when you need it most.",
  },
  {
    title: "Personalization",
    description:
      "We remember your preferences, anticipate your needs, and craft experiences tailored specifically to you.",
  },
]

export function MembershipBenefits() {
  const ref = useRef<HTMLElement>(null)
  const isInView = useInView(ref, { threshold: 0.2 })

  return (
    <section ref={ref} className="relative bg-forest py-24 md:py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <Image
          src="/luxury-members-lounge-dark-elegant-fireplace-leath.jpg"
          alt="Members lounge"
          fill
          className="object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-forest via-forest/95 to-forest/90" />
      </div>

      <div className="relative z-10 mx-auto max-w-[1800px] px-8 md:px-16 lg:px-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-center">
          {/* Content */}
          <div
            className={`transition-all duration-[1500ms] ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
          >
            <span className="block text-[10px] md:text-[11px] tracking-[0.4em] uppercase text-gold font-mono mb-4">
              The Private House Promise
            </span>
            <h2 className="text-3xl md:text-4xl font-serif font-light text-ivory tracking-wide leading-tight">
              What Membership Means
            </h2>
            <p className="mt-6 text-sm text-ivory/60 font-mono leading-relaxed tracking-wide max-w-lg">
              Beyond services, membership represents a relationship built on trust, understanding, and a shared
              appreciation for the exceptional.
            </p>
          </div>

          {/* Benefits Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
            {benefits.map((benefit, index) => (
              <div
                key={benefit.title}
                className={`transition-all duration-[1500ms] ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
                style={{ transitionDelay: `${(index + 1) * 150}ms` }}
              >
                <h3 className="text-lg font-serif font-light text-ivory tracking-wide mb-3">{benefit.title}</h3>
                <p className="text-[11px] text-ivory/50 font-mono leading-relaxed tracking-wide">
                  {benefit.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
