"use client"

import { useRef } from "react"
import { LuxuryButton } from "@/components/ui/luxury-button"
import { useInView } from "@/hooks/use-in-view"

export function MembershipCTA() {
  const ref = useRef<HTMLElement>(null)
  const isInView = useInView(ref, { threshold: 0.3 })

  return (
    <section ref={ref} className="bg-noir py-28 md:py-36">
      <div className="mx-auto max-w-[1800px] px-8 md:px-16 lg:px-24">
        <div
          className={`max-w-2xl mx-auto text-center transition-all duration-[2000ms] ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-16"}`}
        >
          <span className="block text-[9px] md:text-[10px] tracking-[0.5em] uppercase text-gold-muted/70 font-mono mb-5">
            Begin the Conversation
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-serif font-light text-ivory tracking-wide leading-tight">
            Apply for Private Access
          </h2>
          <p className="mt-8 text-[11px] text-ivory/35 font-mono leading-[1.9] tracking-wide max-w-md mx-auto">
            Membership applications are reviewed individually. Existing members may sponsor candidates, or you may
            submit an enquiry directly. All conversations are confidential.
          </p>

          <div className="mt-12">
            <LuxuryButton href="/enquiry" variant="primary" size="lg">
              Submit Enquiry
            </LuxuryButton>
          </div>
        </div>
      </div>
    </section>
  )
}
