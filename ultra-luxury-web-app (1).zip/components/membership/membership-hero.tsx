"use client"

import { useEffect, useState } from "react"
import Image from "next/image"

export function MembershipHero() {
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 100)
    return () => clearTimeout(timer)
  }, [])

  return (
    <section className="relative h-[75vh] min-h-[650px] w-full overflow-hidden bg-noir">
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image
          src="/private-members-club-interior-dark-elegant-library.jpg"
          alt="Private membership"
          fill
          className="object-cover opacity-30"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-b from-noir/70 via-noir/50 to-noir" />
        <div className="absolute inset-0 bg-gradient-to-r from-noir/30 via-transparent to-noir/30" />
      </div>

      {/* Content */}
      <div className="relative z-10 flex h-full flex-col items-center justify-center px-8 text-center pt-28">
        <div
          className={`transition-all duration-[3000ms] ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
        >
          <span className="block text-[9px] md:text-[10px] tracking-[0.6em] uppercase text-gold-muted/70 font-mono mb-8">
            Private Membership
          </span>
          <h1 className="text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-serif font-light text-ivory tracking-wide leading-[1.1] max-w-4xl text-balance">
            By Invitation Only
          </h1>
          <p
            className={`mt-10 text-[11px] md:text-xs text-ivory/35 font-mono tracking-[0.2em] max-w-lg mx-auto transition-all duration-[3000ms] delay-700 ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
          >
            Reserved for those who value discretion, quality, and access to the exceptional.
          </p>
        </div>
      </div>
    </section>
  )
}
