"use client"

import { useRef } from "react"
import { useInView } from "@/hooks/use-in-view"

const tiers = [
  {
    name: "Maison",
    subtitle: "Introduction",
    description:
      "Your introduction to The Private House. Priority booking and dedicated concierge services for the discerning traveler.",
    features: [
      "Dedicated Relationship Manager",
      "Priority Fleet Booking",
      "Concierge Services",
      "Member Events Access",
      "Partner Network Benefits",
    ],
  },
  {
    name: "Maison Privé",
    subtitle: "Elevated",
    description:
      "Enhanced privileges for those who demand the exceptional. Guaranteed availability and expanded access to our world.",
    features: [
      "All Maison Benefits",
      "48-Hour Guaranteed Availability",
      "Private Dining Network",
      "Security Services Access",
      "Lifestyle Management",
      "Exclusive Partner Access",
    ],
    featured: true,
  },
  {
    name: "Maison Héritage",
    subtitle: "By Invitation",
    description:
      "The ultimate expression of membership. Reserved for a select few, by invitation of existing Héritage members only.",
    features: [
      "All Maison Privé Benefits",
      "24-Hour Guaranteed Availability",
      "Dedicated Personal Team",
      "Global Emergency Support",
      "Bespoke Experience Creation",
      "Private House Council",
    ],
  },
]

export function MembershipTiers() {
  const ref = useRef<HTMLElement>(null)
  const isInView = useInView(ref, { threshold: 0.1 })

  return (
    <section ref={ref} className="bg-noir py-28 md:py-36">
      <div className="mx-auto max-w-[1800px] px-8 md:px-16 lg:px-24">
        {/* Header */}
        <div
          className={`max-w-2xl mb-24 transition-all duration-[2000ms] ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-16"}`}
        >
          <span className="block text-[9px] md:text-[10px] tracking-[0.5em] uppercase text-gold-muted/70 font-mono mb-5">
            Membership Tiers
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-serif font-light text-ivory tracking-wide">
            Three Levels of Distinction
          </h2>
        </div>

        {/* Tiers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
          {tiers.map((tier, index) => (
            <div
              key={tier.name}
              className={`relative p-10 lg:p-12 border transition-all duration-[2000ms] ${
                tier.featured ? "border-gold-muted/30 bg-heritage-green/5" : "border-border/10 bg-noir-light/20"
              } ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-16"}`}
              style={{ transitionDelay: `${(index + 1) * 200}ms` }}
            >
              {tier.featured && (
                <span className="absolute -top-3 left-10 px-4 py-1.5 bg-gold-deep text-ivory text-[8px] tracking-[0.3em] uppercase font-mono">
                  Signature
                </span>
              )}

              <span className="text-[9px] tracking-[0.4em] uppercase text-gold-muted/60 font-mono">
                {tier.subtitle}
              </span>
              <h3 className="mt-3 text-2xl md:text-3xl font-serif font-light text-ivory tracking-wide">{tier.name}</h3>
              <p className="mt-5 text-[11px] text-ivory/35 font-mono leading-[1.9] tracking-wide">{tier.description}</p>

              <ul className="mt-10 space-y-5">
                {tier.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-4">
                    <div className="w-0.5 h-4 bg-gold-muted/40 mt-0.5 shrink-0" />
                    <span className="text-[10px] text-ivory/50 font-mono tracking-wide">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <p
          className={`mt-20 text-[10px] text-ivory/20 font-mono tracking-wider text-center transition-all duration-[2000ms] delay-1000 ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
        >
          Membership is by invitation or referral only. Fees are discussed during the application process.
        </p>
      </div>
    </section>
  )
}
