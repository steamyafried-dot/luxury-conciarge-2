"use client"

import type React from "react"
import { useState, useEffect } from "react"
import Image from "next/image"
import { LuxuryButton } from "@/components/ui/luxury-button"

const serviceInterests = [
  "Private Jet Charter",
  "Helicopter Transfers",
  "Ultra-Luxury Ground Transport",
  "Yacht Charter",
  "Private Dining & Chefs",
  "Security & Close Protection",
  "Concierge Services",
  "Bespoke Experiences",
  "Membership Enquiry",
  "Other",
]

export function EnquiryForm() {
  const [isLoaded, setIsLoaded] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    country: "",
    serviceInterest: "",
    message: "",
  })

  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 100)
    return () => clearTimeout(timer)
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    await new Promise((resolve) => setTimeout(resolve, 2500))
    setIsSubmitting(false)
    setIsSubmitted(true)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }))
  }

  if (isSubmitted) {
    return (
      <section className="relative min-h-screen pt-36 pb-28 md:pt-44 md:pb-36 bg-noir">
        <div className="mx-auto max-w-[800px] px-8 md:px-16 text-center">
          <div className="animate-fade-in">
            <span className="block text-[9px] md:text-[10px] tracking-[0.5em] uppercase text-gold font-mono mb-8">
              Enquiry Received
            </span>
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-serif font-light text-ivory tracking-wide leading-tight">
              Thank You
            </h1>
            <p className="mt-10 text-[11px] md:text-xs text-ivory/40 font-mono leading-[1.9] tracking-wide max-w-md mx-auto">
              Your enquiry has been received. A member of our team will be in touch within 24 hours. All communications
              are handled with absolute discretion.
            </p>
            <div className="mt-14">
              <LuxuryButton href="/" variant="outline">
                Return Home
              </LuxuryButton>
            </div>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="relative min-h-screen pt-36 pb-28 md:pt-44 md:pb-36 bg-noir">
      {/* Background */}
      <div className="absolute inset-0">
        <Image
          src="/luxury-private-office-dark-elegant-desk-window-cit.jpg"
          alt="Private enquiry"
          fill
          className="object-cover opacity-15"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-b from-noir via-noir/98 to-noir" />
      </div>

      <div className="relative z-10 mx-auto max-w-[1200px] px-8 md:px-16 lg:px-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 lg:gap-28">
          {/* Left Column - Content */}
          <div
            className={`transition-all duration-[2000ms] ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-16"}`}
          >
            <span className="block text-[9px] md:text-[10px] tracking-[0.5em] uppercase text-gold-muted/70 font-mono mb-8">
              Private Enquiry
            </span>
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-serif font-light text-ivory tracking-wide leading-tight">
              Begin the Conversation
            </h1>
            <p className="mt-10 text-[11px] md:text-xs text-ivory/40 font-mono leading-[1.9] tracking-wide max-w-sm">
              Every journey with The Private House begins with understanding. Share your requirements, and we shall
              respond with discretion and care.
            </p>

            <div className="mt-14 space-y-8">
              {[
                { title: "Absolute Discretion", desc: "All communications are confidential" },
                { title: "Personal Response", desc: "A dedicated team member will be in touch" },
                { title: "No Obligation", desc: "Enquiries are welcome without commitment" },
              ].map((item) => (
                <div key={item.title} className="flex items-start gap-5">
                  <div className="w-0.5 h-12 bg-gold-muted/30" />
                  <div>
                    <h3 className="text-sm font-serif text-ivory/80 tracking-wide">{item.title}</h3>
                    <p className="mt-1.5 text-[10px] text-ivory/30 font-mono tracking-wide">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column - Form */}
          <div
            className={`transition-all duration-[2000ms] delay-500 ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-16"}`}
          >
            <form onSubmit={handleSubmit} className="space-y-10">
              {/* Full Name */}
              <div>
                <label
                  htmlFor="fullName"
                  className="block text-[9px] tracking-[0.4em] uppercase text-ivory/40 font-mono mb-4"
                >
                  Full Name
                </label>
                <input
                  type="text"
                  id="fullName"
                  name="fullName"
                  value={formData.fullName}
                  onChange={handleChange}
                  required
                  className="w-full bg-transparent border-b border-border/20 focus:border-gold-muted py-4 text-sm text-ivory font-mono tracking-wide outline-none transition-colors duration-500"
                  placeholder="Your full name"
                />
              </div>

              {/* Email */}
              <div>
                <label
                  htmlFor="email"
                  className="block text-[9px] tracking-[0.4em] uppercase text-ivory/40 font-mono mb-4"
                >
                  Email Address
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full bg-transparent border-b border-border/20 focus:border-gold-muted py-4 text-sm text-ivory font-mono tracking-wide outline-none transition-colors duration-500"
                  placeholder="your@email.com"
                />
              </div>

              {/* Country */}
              <div>
                <label
                  htmlFor="country"
                  className="block text-[9px] tracking-[0.4em] uppercase text-ivory/40 font-mono mb-4"
                >
                  Country of Residence
                </label>
                <input
                  type="text"
                  id="country"
                  name="country"
                  value={formData.country}
                  onChange={handleChange}
                  required
                  className="w-full bg-transparent border-b border-border/20 focus:border-gold-muted py-4 text-sm text-ivory font-mono tracking-wide outline-none transition-colors duration-500"
                  placeholder="Country"
                />
              </div>

              {/* Service Interest */}
              <div>
                <label
                  htmlFor="serviceInterest"
                  className="block text-[9px] tracking-[0.4em] uppercase text-ivory/40 font-mono mb-4"
                >
                  Service Interest
                </label>
                <select
                  id="serviceInterest"
                  name="serviceInterest"
                  value={formData.serviceInterest}
                  onChange={handleChange}
                  required
                  className="w-full bg-noir border-b border-border/20 focus:border-gold-muted py-4 text-sm text-ivory font-mono tracking-wide outline-none transition-colors duration-500 appearance-none cursor-pointer"
                >
                  <option value="" disabled>
                    Select a service
                  </option>
                  {serviceInterests.map((service) => (
                    <option key={service} value={service} className="bg-noir text-ivory">
                      {service}
                    </option>
                  ))}
                </select>
              </div>

              {/* Message */}
              <div>
                <label
                  htmlFor="message"
                  className="block text-[9px] tracking-[0.4em] uppercase text-ivory/40 font-mono mb-4"
                >
                  Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={4}
                  className="w-full bg-transparent border-b border-border/20 focus:border-gold-muted py-4 text-sm text-ivory font-mono tracking-wide outline-none transition-colors duration-500 resize-none"
                  placeholder="Please share any details about your requirements..."
                />
              </div>

              {/* Submit Button */}
              <div className="pt-6">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="inline-flex items-center justify-center w-full bg-heritage-green text-ivory text-[10px] tracking-[0.25em] uppercase font-mono px-10 py-6 transition-all duration-700 hover:bg-heritage-green-light disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? "Submitting..." : "Submit Enquiry"}
                </button>
              </div>

              {/* Microcopy */}
              <p className="text-[9px] text-ivory/20 font-mono tracking-wider text-center">
                All requests are handled with absolute discretion.
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}
