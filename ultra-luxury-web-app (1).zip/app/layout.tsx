import type React from "react"
import type { Metadata, Viewport } from "next"
import { Cormorant_Garamond, Inter } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"

const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-cormorant",
})

const inter = Inter({
  subsets: ["latin"],
  weight: ["300", "400", "500"],
  variable: "--font-inter",
})

export const metadata: Metadata = {
  title: "THE PRIVATE HOUSE | A Maison for the Discerning Few",
  description:
    "An invitation-only sanctuary of aviation, mobility, and bespoke luxury. Discreet. Private. By referral only.",
  keywords: [
    "private aviation",
    "luxury charter",
    "UHNW",
    "private membership",
    "bespoke concierge",
    "heritage luxury",
  ],
  authors: [{ name: "The Private House" }],
  openGraph: {
    title: "THE PRIVATE HOUSE",
    description: "A Maison for the Discerning Few",
    type: "website",
  },
    generator: 'v0.app'
}

export const viewport: Viewport = {
  themeColor: "#141414",
  width: "device-width",
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className={`${cormorant.variable} ${inter.variable} font-serif antialiased`}>
        <div className="grain-overlay" aria-hidden="true" />
        {children}
        <Analytics />
      </body>
    </html>
  )
}
