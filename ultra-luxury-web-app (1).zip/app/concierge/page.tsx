import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { ConciergeHero } from "@/components/concierge/concierge-hero"
import { ConciergeServices } from "@/components/concierge/concierge-services"

export const metadata = {
  title: "Concierge | The Private House",
  description:
    "Private aviation coordination, yacht charters, security services, and comprehensive lifestyle management for distinguished clients.",
}

export default function ConciergePage() {
  return (
    <main className="min-h-screen bg-noir">
      <Navigation />
      <ConciergeHero />
      <ConciergeServices />
      <Footer />
    </main>
  )
}
