import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { FleetHero } from "@/components/fleet/fleet-hero"
import { FleetCategory } from "@/components/fleet/fleet-category"
import { fleetData } from "@/lib/fleet-data"

export const metadata = {
  title: "Fleet | The Private House",
  description: "Our curated collection of private jets, helicopters, ultra-luxury cars, and yachts.",
}

export default function FleetPage() {
  return (
    <main className="min-h-screen bg-noir">
      <Navigation />
      <FleetHero />

      {fleetData.map((category, index) => (
        <FleetCategory key={category.id} category={category} isReversed={index % 2 !== 0} />
      ))}

      <Footer />
    </main>
  )
}
