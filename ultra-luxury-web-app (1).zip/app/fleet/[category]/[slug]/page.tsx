import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { FleetDetail } from "@/components/fleet/fleet-detail"
import { fleetData } from "@/lib/fleet-data"
import { notFound } from "next/navigation"

interface Props {
  params: Promise<{ category: string; slug: string }>
}

export async function generateMetadata({ params }: Props) {
  const { category, slug } = await params
  const categoryData = fleetData.find((c) => c.id === category)
  const item = categoryData?.items.find((i) => i.slug === slug)

  if (!item) return { title: "Not Found" }

  return {
    title: `${item.name} | Fleet | The Private House`,
    description: item.description,
  }
}

export default async function FleetDetailPage({ params }: Props) {
  const { category, slug } = await params
  const categoryData = fleetData.find((c) => c.id === category)
  const item = categoryData?.items.find((i) => i.slug === slug)

  if (!item) notFound()

  return (
    <main className="min-h-screen bg-charcoal">
      <Navigation />
      <FleetDetail item={item} categoryTitle={categoryData!.title} />
      <Footer />
    </main>
  )
}
