import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { LegalContent } from "@/components/legal/legal-content"

export const metadata = {
  title: "Disclaimer | The Private House",
  description: "Legal disclaimer for The Private House luxury services.",
}

const disclaimerContent = {
  title: "Disclaimer",
  lastUpdated: "January 2024",
  sections: [
    {
      title: "General Information",
      content:
        "The information provided on this website is for general informational purposes only. While we strive to keep the information accurate and current, we make no representations or warranties of any kind about the completeness, accuracy, reliability, or suitability of the information.",
    },
    {
      title: "Service Availability",
      content:
        "All services described on this website are subject to availability and may vary by location. The images and descriptions on this website are representative and may not reflect the exact specifications of the aircraft, vehicles, or vessels available at the time of booking.",
    },
    {
      title: "No Price Display",
      content:
        "In keeping with our commitment to personalized service, we do not display pricing on our website. All quotations are provided directly and are tailored to individual requirements. Prices are subject to change and availability at the time of booking.",
    },
    {
      title: "Third-Party Services",
      content:
        "Many of our services are delivered in partnership with third-party providers. While we carefully select and vet our partners, we cannot guarantee their performance and are not liable for any acts or omissions of third-party service providers.",
    },
    {
      title: "Professional Advice",
      content:
        "The content on this website does not constitute professional, legal, financial, or tax advice. You should consult appropriate professionals for advice specific to your situation.",
    },
    {
      title: "External Links",
      content:
        "This website may contain links to external sites. We have no control over the content or availability of these sites and do not endorse or accept responsibility for them.",
    },
    {
      title: "Intellectual Property",
      content:
        "All content on this website, including text, images, logos, and design, is the property of The Private House or its licensors and is protected by intellectual property laws. Unauthorized use is prohibited.",
    },
    {
      title: "Limitation of Liability",
      content:
        "To the fullest extent permitted by law, The Private House excludes all liability for any loss or damage arising from your use of this website or reliance on any information provided herein.",
    },
  ],
}

export default function DisclaimerPage() {
  return (
    <main className="min-h-screen bg-charcoal">
      <Navigation />
      <LegalContent content={disclaimerContent} />
      <Footer />
    </main>
  )
}
