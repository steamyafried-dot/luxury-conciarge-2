import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { LegalContent } from "@/components/legal/legal-content"

export const metadata = {
  title: "Terms of Service | The Private House",
  description: "Terms of service for The Private House luxury services.",
}

const termsContent = {
  title: "Terms of Service",
  lastUpdated: "January 2024",
  sections: [
    {
      title: "Agreement to Terms",
      content:
        "By accessing or using The Private House services, you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our services. These terms constitute a legally binding agreement between you and The Private House.",
    },
    {
      title: "Eligibility",
      content:
        "Our services are available only to individuals who are at least 18 years of age and who can form legally binding contracts. By using our services, you represent and warrant that you meet these eligibility requirements.",
    },
    {
      title: "Services",
      content:
        "The Private House provides luxury lifestyle management services including, but not limited to, private aviation charter, ground transportation, yacht charter, and concierge services. All services are subject to availability and our acceptance of your booking request.",
    },
    {
      title: "Booking and Payment",
      content:
        "All bookings are subject to confirmation and availability. Payment terms will be communicated at the time of booking confirmation. We reserve the right to require advance payment or deposits for certain services. Cancellation policies vary by service type and will be communicated at the time of booking.",
    },
    {
      title: "Member Conduct",
      content:
        "Members and guests are expected to conduct themselves with respect and discretion at all times. We reserve the right to refuse service or terminate membership for conduct we deem inappropriate or harmful to other members, staff, or our partners.",
    },
    {
      title: "Confidentiality",
      content:
        "We maintain strict confidentiality regarding all member information and activities. We expect members to similarly respect the privacy of other members and our service partners.",
    },
    {
      title: "Limitation of Liability",
      content:
        "To the maximum extent permitted by law, The Private House shall not be liable for any indirect, incidental, special, consequential, or punitive damages arising from your use of our services. Our total liability shall not exceed the fees paid for the specific service giving rise to the claim.",
    },
    {
      title: "Governing Law",
      content:
        "These terms shall be governed by and construed in accordance with the laws of the jurisdiction in which The Private House is registered, without regard to conflict of law principles.",
    },
    {
      title: "Contact",
      content:
        "For questions regarding these Terms of Service, please submit an enquiry through our website or contact your dedicated relationship manager.",
    },
  ],
}

export default function TermsPage() {
  return (
    <main className="min-h-screen bg-charcoal">
      <Navigation />
      <LegalContent content={termsContent} />
      <Footer />
    </main>
  )
}
