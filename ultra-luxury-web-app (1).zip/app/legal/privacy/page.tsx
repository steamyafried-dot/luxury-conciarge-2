import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { LegalContent } from "@/components/legal/legal-content"

export const metadata = {
  title: "Privacy Policy | The Private House",
  description: "Privacy policy for The Private House luxury services.",
}

const privacyContent = {
  title: "Privacy Policy",
  lastUpdated: "January 2024",
  sections: [
    {
      title: "Our Commitment to Privacy",
      content:
        "The Private House is committed to protecting your privacy with the same level of discretion we apply to all aspects of our service. This policy explains how we collect, use, and protect your personal information.",
    },
    {
      title: "Information We Collect",
      content:
        "We collect information you provide directly, including contact details, travel preferences, and service requirements. We may also collect information about your use of our services to improve your experience and our offerings.",
    },
    {
      title: "How We Use Your Information",
      content:
        "We use your information solely to provide and improve our services, communicate with you about bookings and opportunities, and ensure your safety and security. We do not sell or share your information with third parties for marketing purposes.",
    },
    {
      title: "Information Sharing",
      content:
        "We share your information only with service partners necessary to fulfill your bookings (airlines, hotels, ground transport providers, etc.) and only to the extent necessary. All partners are bound by strict confidentiality agreements.",
    },
    {
      title: "Data Security",
      content:
        "We employ industry-leading security measures to protect your personal information. Access to member data is strictly limited to authorized personnel who require it to perform their duties.",
    },
    {
      title: "Data Retention",
      content:
        "We retain your information for as long as necessary to provide our services and comply with legal obligations. Upon request, we will delete your personal information, subject to any legal retention requirements.",
    },
    {
      title: "Your Rights",
      content:
        "You have the right to access, correct, or delete your personal information. You may also request a copy of your data or restrict its processing. To exercise these rights, please contact your relationship manager or submit an enquiry.",
    },
    {
      title: "Cookies and Tracking",
      content:
        "Our website uses essential cookies to ensure functionality. We use analytics to understand how our website is used, but we do not use tracking for advertising purposes.",
    },
    {
      title: "Changes to This Policy",
      content:
        "We may update this policy periodically. We will notify you of any material changes through our website or direct communication.",
    },
    {
      title: "Contact",
      content:
        "For privacy-related enquiries, please submit a request through our website or contact your dedicated relationship manager.",
    },
  ],
}

export default function PrivacyPage() {
  return (
    <main className="min-h-screen bg-charcoal">
      <Navigation />
      <LegalContent content={privacyContent} />
      <Footer />
    </main>
  )
}
