import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { MembershipHero } from "@/components/membership/membership-hero"
import { MembershipTiers } from "@/components/membership/membership-tiers"
import { MembershipBenefits } from "@/components/membership/membership-benefits"
import { MembershipCTA } from "@/components/membership/membership-cta"

export const metadata = {
  title: "Membership | THE PRIVATE HOUSE",
  description:
    "Membership to The Private House is by invitation or referral only. Discover our tiers: Maison, Maison Privé, and Maison Héritage.",
}

export default function MembershipPage() {
  return (
    <main className="min-h-screen bg-noir">
      <Navigation />
      <MembershipHero />
      <MembershipTiers />
      <MembershipBenefits />
      <MembershipCTA />
      <Footer />
    </main>
  )
}
