import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { AboutHero } from "@/components/about/about-hero"
import { AboutPhilosophy } from "@/components/about/about-philosophy"
import { AboutValues } from "@/components/about/about-values"

export const metadata = {
  title: "About | The Private House",
  description:
    "Built on trust, discretion, and an unwavering commitment to excellence. The Private House serves those who value privacy and legacy above all.",
}

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-noir">
      <Navigation />
      <AboutHero />
      <AboutPhilosophy />
      <AboutValues />
      <Footer />
    </main>
  )
}
