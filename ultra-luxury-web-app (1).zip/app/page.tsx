import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { HeroSection } from "@/components/home/hero-section"
import { AviationSection } from "@/components/home/aviation-section"
import { MobilitySection } from "@/components/home/mobility-section"
import { ExperiencesSection } from "@/components/home/experiences-section"
import { MembershipSection } from "@/components/home/membership-section"

export default function HomePage() {
  return (
    <main className="min-h-screen bg-noir">
      <Navigation />
      <HeroSection />
      <AviationSection />
      <MobilitySection />
      <ExperiencesSection />
      <MembershipSection />
      <Footer />
    </main>
  )
}
