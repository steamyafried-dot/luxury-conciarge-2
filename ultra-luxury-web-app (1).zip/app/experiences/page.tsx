import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { ExperiencesHero } from "@/components/experiences/experiences-hero"
import { ExperiencesList } from "@/components/experiences/experiences-list"

export const metadata = {
  title: "Experiences | The Private House",
  description:
    "Bespoke experiences crafted for the exceptional. Private dining, cultural journeys, and curated retreats.",
}

export default function ExperiencesPage() {
  return (
    <main className="min-h-screen bg-charcoal">
      <Navigation />
      <ExperiencesHero />
      <ExperiencesList />
      <Footer />
    </main>
  )
}
