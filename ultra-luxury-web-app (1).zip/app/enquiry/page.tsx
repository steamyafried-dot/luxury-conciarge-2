import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { EnquiryForm } from "@/components/enquiry/enquiry-form"

export const metadata = {
  title: "Private Enquiry | The Private House",
  description: "Submit a private request. All enquiries are handled with absolute discretion.",
}

export default function EnquiryPage() {
  return (
    <main className="min-h-screen bg-noir">
      <Navigation />
      <EnquiryForm />
      <Footer />
    </main>
  )
}
