export interface FleetItem {
  slug: string
  name: string
  subtitle: string
  description: string
  image: string
  interiorImage?: string
  detailImage?: string
  specs?: Record<string, string>
}

export interface FleetCategoryType {
  id: string
  eyebrow: string
  title: string
  description: string
  items: FleetItem[]
}

export const fleetData: FleetCategoryType[] = [
  {
    id: "jets",
    eyebrow: "Private Aviation",
    title: "Private Jets",
    description:
      "The world's finest aircraft, meticulously maintained and crewed by elite aviation professionals. Each journey tailored to your exacting standards.",
    items: [
      {
        slug: "gulfstream-g700",
        name: "Gulfstream G700",
        subtitle: "Ultra Long Range",
        description:
          "The flagship of the Gulfstream fleet, the G700 redefines ultra-long-range travel. With the largest cabin in the industry, award-winning design, and unmatched range, it represents the absolute pinnacle of private aviation.",
        image: "/gulfstream-g700-exterior-private-jet-tarmac-sunset-.jpg",
        interiorImage: "/gulfstream-g700-interior-luxury-cabin-leather-seat.jpg",
        detailImage: "/gulfstream-g700-cockpit-detail-modern-avionics-lux.jpg",
        specs: {
          Range: "7,500 nm",
          Passengers: "Up to 19",
          "Cabin Height": "6'3\"",
          "Max Speed": "Mach 0.925",
        },
      },
      {
        slug: "bombardier-global-8000",
        name: "Bombardier Global 8000",
        subtitle: "Ultra Long Range",
        description:
          "Setting new standards in range and refinement, the Global 8000 connects continents with effortless grace. The Nuage seating system and Soleil lighting create an environment of unparalleled comfort.",
        image: "/bombardier-global-8000-exterior-white-private-jet-r.jpg",
        interiorImage: "/bombardier-global-8000-interior-nuage-seats-luxury.jpg",
        detailImage: "/bombardier-global-8000-cabin-detail-wood-veneer-lu.jpg",
        specs: {
          Range: "8,000 nm",
          Passengers: "Up to 17",
          "Cabin Width": "8'2\"",
          "Max Speed": "Mach 0.94",
        },
      },
      {
        slug: "dassault-falcon-10x",
        name: "Dassault Falcon 10X",
        subtitle: "Ultra Long Range",
        description:
          "French elegance meets revolutionary engineering. The Falcon 10X features the largest cabin cross-section in business aviation and innovative FalconEye technology for enhanced safety.",
        image: "/dassault-falcon-10x-exterior-sleek-private-jet-runn.jpg",
        interiorImage: "/dassault-falcon-10x-interior-wide-cabin-luxury-sea.jpg",
        detailImage: "/dassault-falcon-10x-window-detail-large-oval-windo.jpg",
        specs: {
          Range: "7,500 nm",
          Passengers: "Up to 16",
          "Cabin Height": "6'8\"",
          "Max Speed": "Mach 0.925",
        },
      },
    ],
  },
  {
    id: "helicopters",
    eyebrow: "Rotary Wing",
    title: "Helicopters",
    description:
      "From coastal transfers to alpine arrivals, our helicopter fleet provides unmatched flexibility and access to destinations beyond the reach of conventional aircraft.",
    items: [
      {
        slug: "airbus-h145",
        name: "Airbus H145",
        subtitle: "Twin Engine",
        description:
          "The H145 combines versatility with refinement, offering VIP configurations that transform regional travel into an experience of quiet luxury. Ideal for city-to-city transfers and exclusive destination access.",
        image: "/airbus-h145-helicopter-vip-black-flying-over-coast.jpg",
        interiorImage: "/airbus-h145-interior-vip-leather-seats-luxury-heli.jpg",
        specs: {
          Range: "400 nm",
          Passengers: "Up to 8",
          "Cruise Speed": "145 kts",
          "Cabin Volume": "6.8 m³",
        },
      },
      {
        slug: "bell-429",
        name: "Bell 429",
        subtitle: "Light Twin",
        description:
          "Sleek, powerful, and remarkably quiet, the Bell 429 delivers executive transport with contemporary style. Its spacious cabin and smooth ride make it the choice for discerning travelers.",
        image: "/bell-429-helicopter-white-luxury-helipad-city-skyl.jpg",
        interiorImage: "/bell-429-interior-executive-configuration-leather-.jpg",
        specs: {
          Range: "390 nm",
          Passengers: "Up to 7",
          "Cruise Speed": "150 kts",
          "Cabin Width": "5'7\"",
        },
      },
      {
        slug: "leonardo-aw139",
        name: "Leonardo AW139",
        subtitle: "Medium Twin",
        description:
          "The AW139 sets the standard for VIP helicopter travel, with exceptional range, speed, and cabin comfort. Trusted by heads of state and industry leaders worldwide.",
        image: "/leonardo-aw139-helicopter-vip-white-flying-yacht-m.jpg",
        interiorImage: "/leonardo-aw139-interior-vip-configuration-luxury-c.jpg",
        specs: {
          Range: "573 nm",
          Passengers: "Up to 12",
          "Cruise Speed": "165 kts",
          "Cabin Height": "4'8\"",
        },
      },
    ],
  },
  {
    id: "cars",
    eyebrow: "Ground Transport",
    title: "Ultra-Luxury Cars",
    description:
      "Chauffeured excellence across the world's most distinguished destinations. Each vehicle selected for its combination of presence, comfort, and discretion.",
    items: [
      {
        slug: "rolls-royce-phantom",
        name: "Rolls-Royce Phantom",
        subtitle: "Extended Wheelbase",
        description:
          "The motor car. The Phantom represents the absolute pinnacle of automotive luxury, where every journey becomes an occasion. Hand-crafted interiors and the iconic Spirit of Ecstasy announce arrival with quiet authority.",
        image: "/rolls-royce-phantom-black-exterior-night-city-ligh.jpg",
        interiorImage: "/rolls-royce-phantom-interior-starlight-headliner-l.jpg",
        specs: {
          Engine: "6.75L V12",
          Power: "563 hp",
          Wheelbase: "Extended",
          Interior: "Bespoke",
        },
      },
      {
        slug: "bentley-mulsanne",
        name: "Bentley Mulsanne",
        subtitle: "Grand Limousine",
        description:
          "British craftsmanship at its finest. The Mulsanne combines continent-crossing capability with the intimacy of a private members' club, wrapped in hand-stitched leather and burr walnut.",
        image: "/bentley-mulsanne-dark-green-exterior-stately-home-.jpg",
        interiorImage: "/bentley-mulsanne-interior-rear-seats-champagne-coo.jpg",
        specs: {
          Engine: "6.75L V8",
          Power: "505 hp",
          "0-60": "5.1 seconds",
          Interior: "Mulliner",
        },
      },
      {
        slug: "mercedes-maybach-s-class",
        name: "Mercedes-Maybach S-Class",
        subtitle: "S 680",
        description:
          "German engineering elevated to the realm of the exceptional. The Maybach S-Class offers technological sophistication wrapped in an atmosphere of serene refinement.",
        image: "/mercedes-maybach-s-class-silver-exterior-hotel-ent.jpg",
        interiorImage: "/mercedes-maybach-s-class-interior-executive-rear-s.jpg",
        specs: {
          Engine: "6.0L V12",
          Power: "621 hp",
          "Magic Body": "Control",
          Sound: "Burmester 4D",
        },
      },
      {
        slug: "range-rover-sv",
        name: "Range Rover SV",
        subtitle: "Long Wheelbase",
        description:
          "Commanding presence meets refined capability. The Range Rover SV delivers executive comfort with the assurance of going anywhere, in any condition.",
        image: "/range-rover-sv-gray-exterior-alpine-mountain-road-.jpg",
        interiorImage: "/range-rover-sv-interior-four-seat-configuration-lu.jpg",
        specs: {
          Engine: "4.4L V8",
          Power: "523 hp",
          Configuration: "4-Seat",
          Interior: "SV Bespoke",
        },
      },
    ],
  },
  {
    id: "yachts",
    eyebrow: "Maritime",
    title: "Yachts",
    description:
      "The freedom of the open sea, with every comfort attended to. Our yacht collection represents the finest vessels available for private charter in the Mediterranean and beyond.",
    items: [
      {
        slug: "classic-40m",
        name: "40m Classic",
        subtitle: "Mediterranean",
        description:
          "Timeless elegance on the water. This 40-meter yacht combines classic styling with modern amenities, perfect for intimate gatherings and coastal exploration.",
        image: "/luxury-yacht-40m-white-mediterranean-sea-aerial-vi.jpg",
        interiorImage: "/luxury-yacht-interior-salon-cream-leather-wood-pan.jpg",
        specs: {
          Length: "40m",
          Guests: "10",
          Crew: "8",
          Cruising: "Mediterranean",
        },
      },
      {
        slug: "modern-55m",
        name: "55m Modern",
        subtitle: "Global",
        description:
          "Contemporary design meets ocean-going capability. This 55-meter superyacht offers expansive deck spaces, a beach club, and accommodations rivaling the finest hotels.",
        image: "/luxury-superyacht-55m-modern-design-sunset-ocean-a.jpg",
        interiorImage: "/luxury-superyacht-interior-master-suite-panoramic-w.jpg",
        specs: {
          Length: "55m",
          Guests: "12",
          Crew: "12",
          Range: "Transatlantic",
        },
      },
    ],
  },
]
